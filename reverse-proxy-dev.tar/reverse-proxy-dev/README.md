### Simple Project to test Gitlab-CI


**1. First you need to install gitlab-runner in any instance which is accessable from the original gitlab running instance**


* Simply download one of the binaries for your system
        
        sudo wget -O /usr/local/bin/gitlab-runner https://gitlab-runner-downloads.s3.amazonaws.com/latest/binaries/gitlab-runner-linux-amd64

* Give it permissions to execute:
        
        sudo chmod +x /usr/local/bin/gitlab-runner
 
* Create a GitLab CI user:
        
        sudo useradd --comment 'GitLab Runner' --create-home gitlab-runner --shell /bin/bash
  
* Install and run as service:
        
        sudo gitlab-runner install --user=gitlab-runner --working-directory=/home/gitlab-runner
        
        sudo gitlab-runner start
 
* Give gitlab-runner access to docker
        
        sudo usermod -aG docker gitlab-runner


**2.  Now configure the runner**

* While configuring it will ask for gitlab url and passcode.

        sudo gitlab-runner register

* Start the gitlab runner

        sudo gitlab-runner start/stop/status
        
        
**3.  Maintaining**


        /etc/gitlab-runner is where the .toml file is. Check the configuration of the runners.
        
        
**4.  About the gitlab-runner to be configured in GitLab**
    
    *   There are 2 types of runners
            
             1. Private runner
             2. Shared runner

 **Private Runner**

         1. You can have a runner for 1 project by configuring it straight from the gitlab project repository. Just go to settings / CI/CD 
         then runner and choose the token which corresponds to the individual repo.
         2. This runner will  only work for this project.
    
 **Shared Runner**

         1. You can configure a shared runner which can be configured by admins only. This runner can be configured in the admin area /Overview/Runners.
         2. This is the shared runner which can be configuired to run multiple pipelines. You will have an option to configure it based on projects.
    
        
        